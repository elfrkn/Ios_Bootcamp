import UIKit

// 1-Parametre olarak girilen kilometreyi mile dönüştürdükten sonra geri döndüren metod.(mile=km*0.621)

class kmToMile {
    
    func mile(km:Double) -> Double{
        let result = (km * 0.621)
        return result
    }
    
}

let f = kmToMile()
let mileResult = f.mile(km: 50)
print("Hesaplanan mile: \(mileResult)")

// 2-Kenarları parametre olarak girilen ve dikdörtgenin alanını hesaplayan metod.

class Area {
    
    func rectangle(longSide:Int,shortSide:Int) {
        let result = longSide * shortSide
        print("Dikdörtgenin Alanı: \(result)")
    }
}

let areaResult = Area()
areaResult.rectangle(longSide: 15, shortSide: 4)

// 3-Parametre olarak girilen sayının faktöriyel değerini hesaplayıp geri döndüren metod.

class Factorial {
    
    func number(num:Int) -> Int{
        var sonuc = 1
        for i in 1...num{
            sonuc *= i
        }
        return sonuc
    }
}

let fResult = Factorial()
let facResult = fResult.number(num: 5)
print("Faktöriyel Hesaplama: \(facResult)")

// 4-Parametre olarak girilen kelime içinde kaç adet "e" harfi olduğunu gösteren metod.

class Name {
    
    func fName(name:String) {
        var sayac = 0
        for character in name {
            if character == "e" || character == "E" {
                sayac += 1
            }
           
        }
        print("Girilen kelimede \(sayac) adet <e> kelimesi vardır")
    }
}

let letter = Name()
letter.fName(name: "Esenlikler")

// 5-Parametre olarak girilen kenar sayısına göre her bir iç açıyı hesaplayıp sonucu geri döndüren metod.

class aciToplam {
    
    func icAci(kenarSayisi:Int) -> Int {
        let icAciToplam = (kenarSayisi - 2) * 180 / kenarSayisi
        return icAciToplam
    }
}

let toplamSonuc = aciToplam()
let toplam = toplamSonuc.icAci(kenarSayisi: 5)
print(toplam)

// 6- Parametre olarak girilen gün sayısına göre maaş hesabı yapan ve elde edilen değeri döndüren metod.

class Maas {
    
    func hesap(gunSayisi:Int) -> Int{
        let toplamSaat = gunSayisi * 8
        var toplamUcret = 1
        let farkSaat = toplamSaat - 150
        let farkUcret = farkSaat * 80
        
        
        if toplamSaat > 150 {
            toplamUcret =  (150 * 40 ) + farkUcret
            print(toplamUcret)
        }else {
           
          toplamUcret = toplamSaat * 40
            print(toplamUcret)
        }
        
        return toplamUcret
        
        
    }
}

let u = Maas()
let gelensonuc = u.hesap(gunSayisi: 5)
print("Toplam Maaş : \(gelensonuc)")

// 7- Parametre olarak girilen otopark süresine göre otopark ücretini hesaplayarak geri döndüren metod.

class Otopark {
    
    func park(sure:Int) -> Int {
         
        var hesaplananUcret = 1
        var asimUcret = 10
    
        
        if sure == 1 {
            hesaplananUcret = sure * 50
            print(hesaplananUcret)
        }else {
            var asimSure = sure - 1
            hesaplananUcret = (asimSure * asimUcret) + 50
            print(hesaplananUcret)
            
        }
        
        return hesaplananUcret
        
    }
    
}

let h = Otopark()
let sonuc = h.park(sure: 3)
print("Otopark Ücreti: \(sonuc)")

