import UIKit

var customerSurname = "Çalış"
var productNumber = 346
var payNumber = 3500
var fileName = "Ödemeler"
var cargoNumber = 235

print ("Müşteri Soyadı : \(customerSurname)")
print ("Ürün Miktarı : \(productNumber)")
print ("Ödeme Miktarı : \(payNumber)")
print ("Dosya Adı : \(fileName)")
print ("Kargo Takip No : \(cargoNumber)")

